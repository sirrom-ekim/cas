<x-layouts.app :title="__('Dashboard')">
    <div class="flex h-full w-full flex-1 flex-col gap-4 rounded-xl">
        <div class="relative h-full flex-1 overflow-hidden rounded-xl border border-neutral-200 dark:border-neutral-700">

<iframe src="https://workdrive.zohoexternal.com/embed/a7rxa24b408e40f53458b94a75a01028b8139?hidetheme=true&toolbar=false&layout=list&appearance=dark&themecolor=green" scrolling="no" frameborder="0" allowfullscreen="true" width="100%" height="100%" title="Embed code"></iframe>

        </div>
    </div>
</x-layouts.app>
