

<div <?php echo e($attributes->class('flex-1')); ?> data-flux-spacer></div>
<?php /**PATH C:\laragon\www\cas\vendor\livewire\flux\src/../stubs/resources/views/flux/spacer.blade.php ENDPATH**/ ?>